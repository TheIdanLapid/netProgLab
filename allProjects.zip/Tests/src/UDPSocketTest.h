/*
 * UDPSocketTest.h
 *
 *  Created on: May 8, 2017
 *      Author: user
 */

#ifndef UDPSOCKETTEST_H_
#define UDPSOCKETTEST_H_

namespace networking {
class UDPSocketTest {
public:
	UDPSocketTest();
	bool testUDPSocket();
	virtual ~UDPSocketTest();
};
}

#endif /* UDPSOCKETTEST_H_ */
